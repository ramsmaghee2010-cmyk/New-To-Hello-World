## Model sources
[Mike Lud](https://github.com/MikeLud/CodeProject.AI-Custom-IPcam-Models) 

 - IPcam-animal.pt
 - IPcam-combined.pt
 - IPcam-dark.pt
 - IPcam-general.pt

[Mike Lud](https://github.com/MikeLud/DeepStack-Security-Camera-Models)

 - licence-plate.pt

[Olafenwa Moses](https://github.com/OlafenwaMoses/DeepStack_ActionNET)

- actionnetv2.pt

