﻿namespace Yolov5Net.Scorer
{
    /// <summary>
    /// Enum to specify type of detected object.
    /// </summary>
    public enum YoloLabelKind
    {
        Generic
    }
}
