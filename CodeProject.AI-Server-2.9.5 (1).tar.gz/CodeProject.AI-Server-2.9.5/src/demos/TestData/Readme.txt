Copy all the images to the testdata.zip file.
Copy the testdata.zip file to src\server\wwwroot.

Note: a liked file does not work as the link only exists in the project file and so the file does not exist when running debug.